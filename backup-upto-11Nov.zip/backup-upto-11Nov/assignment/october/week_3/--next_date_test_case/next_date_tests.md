| Description | Input | Output |
| --- | --- | --- |
| Simple increment of a normal day | 15-03-2021 | 16-03-2021 |
|  handle out of Range date | 32-03-2021 | "Invalid Date" |
|  handle out of Range date | 29-02-2023 | "Invalid Date" |
|  handle out of Range date leap year | 30-02-2024 | "Invalid Date" |
|  handle out of Range date| 29-02-2023 |"Invalid Date"|
|  handle out of Range date| 31-12-0000 |01-01-0001|
|  change year and month and date | 31-12-2024 | 01-01-2025|
|  change month and date | 30-11-2024 | 01-12-2024|
|  change month and date | 29-02-2024 | 01-03-2024|
|  change month and date | 28-02-2023 | 01-03-2023|
|  change month and date | 30-04-2023 | 01-05-2023|
|   handle out of Range date | 31-04-2023 | "Invalid Date" |
| | | |