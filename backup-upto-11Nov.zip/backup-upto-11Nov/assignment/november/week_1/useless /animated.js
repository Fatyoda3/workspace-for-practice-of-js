const FISH = '🐹';

const delay = function () {
  for (let _ = 0; _ < 10e8; _++);
}
const fillSlides = function (max) {
  const buffer = [];
  for (let index = 0; index < max; index++) {
    buffer.push('*'.repeat(index) + FISH + "*".repeat(max - index - 1));
  }
  for (let index = max - 1; index > 0; index--) {
    buffer.push('*'.repeat(index - 1) + FISH + "*".repeat(max - index));
  }
  return buffer;
}
animateSequence = function (text) {
  console.log(text);
  delay();
  console.clear();
}
const animate = function () {
  const max = 50;
  const buffer = fillSlides(max);

  while (true) {
    for (let index = 0; index < buffer.length; index++) {
      animateSequence(buffer[index]);
    }
  }
}
animate();
