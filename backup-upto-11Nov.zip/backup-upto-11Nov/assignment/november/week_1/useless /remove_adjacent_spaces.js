const SPACE = " ";

function removeAdjacentDuplicateSpaces(sentence) {
  const edited = [];

  return edited.join("");
}

function testRemove(input, expectedValue) {
  const valueWeGot = removeAdjacentDuplicateSpaces(input);
  const isWorking = valueWeGot === expectedValue ? " ✅" : " ❌";
  const inputs = "INPUT|" + input + "\n";
  const expectedPart = expectedValue + "|and we got|" + valueWeGot + "|";
  const message = inputs + "|" + "expected |" + expectedPart + isWorking;

  console.log(message);
}

function testAll() {
  testRemove("hello\t)", "hello\t)");
  testRemove("red  a", "red a");
  testRemove("   red is blue ", " red is blue ");
  testRemove("", "");
  testRemove("  ", " ");
}

testAll();