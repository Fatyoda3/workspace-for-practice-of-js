const toUpper = function (text) {
  return text.toUpperCase()
}
const toLower = function (text) {
  return text.toLowerCase()
}

const changeCase = function (fnToUse, text) {
  return fnToUse(text);
}

const getCase = function () {
  const fnToUse = Deno.args[0] === 'upper';
  return fnToUse ? toUpper : toLower;
}

const main = function () {
  const text = changeCase(getCase(), Deno.args[1]);
  console.log(text);
}

main();