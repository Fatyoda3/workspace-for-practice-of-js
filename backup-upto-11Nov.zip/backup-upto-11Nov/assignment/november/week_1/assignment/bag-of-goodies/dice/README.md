# Dice Simulator

## Description

This program simulates rolling dice according to customizable probability distributions. It displays the results of multiple dice rolls as emoji and provides statistics comparing the actual roll frequencies to the expected probabilities.

## Usage

Run the program using Deno:

```
deno run dice.js [numRolls] [p1 p2 p3 p4 p5 p6]
```

Parameters:

- `numRolls`: Number of dice to roll (default: 100)
- `p1...p6`: Probability for each face (must sum to 1)

Example:

```
deno run dice.js 200 0.1 0.1 0.2 0.2 0.2 0.2
```

## Experiment

Try changing the number of rolls and the probability distribution to see how the results compare to expected values. The larger the sample size, the closer the actual results should be to the expected probabilities.

## Key Concepts to Explore

1. **Probability Distributions** - The program uses custom probability distributions to determine dice roll outcomes, showing how events can be weighted differently.
2. **Random Number Generation** - Using random values to simulate events with specific probabilities.
3. **Statistics** - Calculating and displaying frequency analysis of random events.
4. **Cumulative Probability** - Using a technique where random values are mapped to outcomes based on their cumulative probability.

### Real-world Applications

- **Simulations** - Similar probability models are used in weather forecasting, traffic predictions, and economic models
- **Game Development** - Game designers use weighted probabilities to balance game mechanics and create engaging gameplay
- **Risk Analysis** - Insurance companies use probability distributions to calculate premiums based on the likelihood of various events
- **Scientific Research** - Researchers use random sampling and probability in experimental design and data analysis

Try modifying the code to create dice with more or fewer faces, or to visualize the distribution of results with different graphical representations!
