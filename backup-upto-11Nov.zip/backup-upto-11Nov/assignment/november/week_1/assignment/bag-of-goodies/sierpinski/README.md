# Sierpinski Triangle Generator

## Description

This program generates a Sierpinski triangle using the chaos game method. It creates a fractal pattern by repeatedly plotting points that are halfway between the current position and a randomly selected vertex of an initial triangle.

## Usage

Run the program using Deno:

```
deno run sierpinski.js [width] [height] [iterations]
```

Parameters:

- `width`: Width of the output grid (default: 80)
- `height`: Height of the output grid (default: 40)
- `iterations`: Number of points to plot (default: 10000)

Example:

```
deno run sierpinski.js 100 50 20000
```

## Experiment

Try different values for width, height, and iterations to see how the fractal pattern develops. With more iterations, you'll see a clearer Sierpinski triangle emerge. You can also modify the code to use different characters for the points or try changing the algorithm to create variations of the pattern.

## Key Concepts to Explore

1. **Fractals** - Self-similar patterns that repeat at different scales, created through iteration.
2. **Chaos Game** - A method of creating fractals using random processes with deterministic rules.
3. **Midpoint Calculation** - Finding the point halfway between two points in a coordinate system.
4. **Emergent Complexity** - How simple rules can create complex, beautiful patterns over many iterations.

### Real-world Applications

- **Computer Graphics** - Fractal algorithms are used to generate realistic textures for mountains, clouds, and other natural objects
- **Antenna Design** - Fractal patterns are used in designing compact antennas with multi-band capabilities
- **Data Compression** - Fractal compression techniques use self-similarity to efficiently encode images
- **Financial Analysis** - Fractal mathematics is used to analyze stock market patterns and price movements

Try modifying the code to create other fractal patterns, such as the Barnsley fern or a modified version with different midpoint ratios!
