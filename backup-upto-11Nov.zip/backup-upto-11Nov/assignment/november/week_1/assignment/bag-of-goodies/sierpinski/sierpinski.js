function getRandomVertex(vertices) {
  const randomIndex = Math.floor(Math.random() * vertices.length);
  return vertices[randomIndex];
}

function midpoint(p1, p2) {
  const x = (p1[0] + p2[0]) / 2;
  const y = (p1[1] + p2[1]) / 2;
  return [x, y];
}

function initializeCanvas(width, height) {
  const canvas = [];
  for (let h = 0; h < height; h++) {
    const row = [];
    for (let w = 0; w < width; w++) {
      row.push(' ');
    }
    canvas.push(row);
  }
  return canvas;
}

function drawPoint(canvas, x, y) {
  // Make sure the point is within bounds and round to nearest integer
  const roundedX = Math.round(x);
  const roundedY = Math.round(y);

  if (
    roundedX >= 0 &&
    roundedX < canvas[0].length &&
    roundedY >= 0 &&
    roundedY < canvas.length
  ) {
    canvas[roundedY][roundedX] = '■';
  }
}

function drawSierpinski(width, height, iterations) {
  // Initialize an empty canvas
  const canvas = initializeCanvas(width, height);

  // Define vertices for a right-angled triangle with base at bottom
  const vertices = [
    [0, 0], // Top left
    [width - 1, 0], // Top right
    [width - 1, height - 1], // Bottom right
  ];

  // Start with a random point inside the triangle
  let currentPoint = [
    Math.floor(Math.random() * width),
    Math.floor(Math.random() * height),
  ];

  // Chaos game algorithm
  for (let i = 0; i < iterations; i++) {
    const randomVertex = getRandomVertex(vertices);
    currentPoint = midpoint(currentPoint, randomVertex);
    drawPoint(canvas, currentPoint[0], currentPoint[1]);
  }

  // Convert canvas to string
  const result = canvas.map(row => row.join('')).join('\n');
  return result;
}

function main(args) {
  const width = +args[0] || 80;
  const height = +args[1] || 40;
  const iterations = +args[2] || 10000;

  console.log(drawSierpinski(width, height, iterations));
}

main(Deno.args);
