# Random Sentence Generator

## Description

This program generates random sentences using a simple grammar system. It uses grammar rules with multiple possible productions to create varied, grammatically correct sentences by recursively expanding non-terminal symbols into terminal words.

## Usage

Run the program using Deno:

```
deno run sentence.js [count]
```

Parameters:

- `count`: Number of sentences to generate (default: 5)

Example:

```
deno run sentence.js 10
```

## Experiment

Try modifying the grammar rules in the `createGrammar` function to include more nouns, verbs, adjectives, or entirely new grammatical structures. You can make the sentences more complex by adding prepositional phrases, adverbs, or different verb tenses.

## Key Concepts to Explore

1. **Formal Grammars** - Using production rules to generate sentences according to a structured syntax.
2. **Recursion** - The program uses recursive symbol expansion to build sentences.
3. **Context-Free Grammar** - A type of formal grammar where rules replace a single non-terminal symbol with a sequence of terminals and/or non-terminals.
4. **Randomization** - Using random selection to create varied output from the same set of rules.

### Real-world Applications

- **Natural Language Processing** - Similar grammar systems are used in chatbots, voice assistants, and machine translation
- **Programming Languages** - Compilers use formal grammars to parse and understand code syntax
- **Procedural Content Generation** - Video games use grammar systems to generate quests, dialogues, and descriptions
- **Automated Writing** - News organizations use grammar systems to generate routine articles like financial reports or sports summaries

Try extending the grammar to generate more complex sentences or even simple stories with multiple related sentences!
