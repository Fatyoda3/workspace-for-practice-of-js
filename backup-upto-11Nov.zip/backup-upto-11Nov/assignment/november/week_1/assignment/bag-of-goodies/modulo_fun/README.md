# Modulo Fun

## Description

This program generates colorful patterns using modulo operations to create various grid designs. It includes different pattern algorithms such as checkerboard, cycled, staggered, product, diagonal, and sine-based patterns, all using emojis as tiles.

## Usage

Run the program using Deno:

```
deno run modulo_fun.js [pattern] [rows] [cols] [tileSet]
```

Parameters:

- `pattern`: The pattern algorithm to use (checkerboard, cycled, product, staggered, sine-of-the-times, diagonal)
- `rows`: Number of rows in the pattern (default: 10)
- `cols`: Number of columns in the pattern (default: 10)
- `tileSet`: The set of emoji tiles to use (square, round, diamond)

Example:

```
deno run modulo_fun.js checkerboard 20 20 round
```

## Experiment

Try different combinations of patterns and tile sets to create unique designs. You can also experiment with the grid dimensions to see how patterns scale. For advanced exploration, try modifying the code to create your own pattern algorithms.

## Key Concepts to Explore

1. **Modulo Operation** - Using remainder calculations to create repeating patterns.
2. **Pattern Generation** - Algorithms for creating various grid patterns.
3. **2D Arrays** - Using nested loops to generate a grid of characters.
4. **Mathematical Functions** - Using functions like sine to create more complex patterns.

### Real-world Applications

- **Textile Design** - Similar pattern algorithms are used to create fabric and wallpaper designs
- **Computer Graphics** - Tiling and pattern algorithms are essential in creating textures for 3D models
- **Game Development** - Procedural generation of game worlds often relies on pattern algorithms
- **Computer Security** - Modulo operations are fundamental in cryptographic algorithms and hash functions

Try adding your own pattern algorithms or modifying the existing ones to create unique visual effects!
