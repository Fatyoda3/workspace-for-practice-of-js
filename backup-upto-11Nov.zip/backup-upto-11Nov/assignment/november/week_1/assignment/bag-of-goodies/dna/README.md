# DNA Strand Generator

## Description
This program generates a visual representation of a DNA strand using emojis. It creates a double-helix pattern with blue and yellow spheres representing the base pairs, connected by equals signs to represent the hydrogen bonds.

## Usage
Run the program using Deno:

```
deno run dna.js
```

The program will generate a DNA strand with 40 base pairs by default.

## Experiment
Try modifying the following values in the `main()` function to see how they affect the DNA strand:
- `strandLength` - increase or decrease the number of base pairs
- `amplitude` - change the width of the DNA helix
- `wavelength` - adjust the frequency of the sine wave (how tightly coiled the DNA appears)

## Key Concepts to Explore
1. **Sine Wave Mathematics** - The program uses sine waves to create the helical structure of DNA. Understanding how sine functions work helps in creating repeating patterns.
2. **Parametric Equations** - The program uses mathematical equations with parameters to generate the visual pattern.
3. **DNA Structure** - The program mimics the double-helix structure of DNA, with pairs of bases (represented by colored balls) connected across the strand.

### Real-world Applications
- **Scientific Visualization** - Similar techniques are used to visualize complex scientific data
- **Computer Graphics** - Sine waves and parametric equations are fundamental in creating animations and visual effects
- **Bioinformatics** - Understanding DNA structure visualization is important in genetic research and bioinformatics tools
- **Digital Art** - Mathematical patterns like those created in this program are used in generative art

Enjoy exploring the code and learning about both the programming and scientific concepts behind DNA structure!