# ASCII Art Text Generator

## Description

This program generates ASCII art text using different font styles. It converts regular text into large, stylized text patterns using ASCII characters. The program includes two font styles: a "block" style with larger characters and a "simple" style with smaller characters.

## Usage

Run the program using Deno:

```
deno run fonts.js [text] [font]
```

Parameters:

- `text`: The text to convert to ASCII art (default: "Hello!")
- `font`: The font style to use - "block" or "simple" (default: "block")

Example:

```
deno run fonts.js "JavaScript" simple
```

## Experiment

Try different text inputs and switch between the font styles to see how they look. You can also modify the code to add new font styles or change the character patterns used for existing fonts.

## Key Concepts to Explore

1. **Character Mapping** - Converting regular characters to patterns of ASCII characters.
2. **Multi-line Text Representation** - Using arrays of strings to represent taller characters.
3. **String Manipulation** - Concatenating strings and padding text to create consistent widths.
4. **Modular Design** - The program separates font definitions from the rendering logic.

### Real-world Applications

- **User Interfaces** - ASCII art is used in terminal-based applications and older systems to create interfaces without graphics
- **Banners & Logos** - ASCII art is used for creating text banners in emails, documentation, and command-line tools
- **Text Processing** - Similar techniques are used in text formatting and typesetting systems
- **Legacy Systems** - Many older systems that don't support graphics use ASCII characters to create visual elements

Try extending the program by adding more font styles, supporting lowercase letters, or adding color to the output!
