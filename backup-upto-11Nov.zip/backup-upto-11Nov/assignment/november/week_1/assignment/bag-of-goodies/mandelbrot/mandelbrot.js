// filepath: /Users/srijays/projects/step-11/dna/mandelbrot/mandelbrot.js
// Mandelbrot set renderer using ASCII characters
// This program renders a textual representation of the Mandelbrot set

// Function to calculate if a point is in the Mandelbrot set
// Returns the number of iterations (for coloring) or maxIterations if the point is in the set
function calculateMandelbrot(x0, y0, maxIterations) {
  let x = 0;
  let y = 0;
  let iteration = 0;
  
  // Use the standard Mandelbrot algorithm: z_{n+1} = z_n^2 + c
  // Check if the point escapes to infinity
  while (x*x + y*y <= 4 && iteration < maxIterations) {
    // Calculate z^2 + c
    const xTemp = x*x - y*y + x0;
    y = 2*x*y + y0;
    x = xTemp;
    
    iteration++;
  }
  
  return iteration;
}

// Function to choose a character based on the number of iterations
function chooseChar(iteration, maxIterations) {
  if (iteration === maxIterations) {
    return '█'; // Point is in the set
  }
  
  // Use different characters for different "depths" outside the set
  const ratio = iteration / maxIterations;
  
  if (ratio > 0.9) {
    return '@';
  } else if (ratio > 0.7) {
    return '#';
  } else if (ratio > 0.5) {
    return '*';
  } else if (ratio > 0.3) {
    return '+';
  } else if (ratio > 0.1) {
    return '.';
  } else {
    return ' ';
  }
}

// Function to render the Mandelbrot set
function renderMandelbrot(width, height, xMin, xMax, yMin, yMax, maxIterations) {
  const lines = [];
  
  for (let h = 0; h < height; h++) {
    let line = '';
    for (let w = 0; w < width; w++) {
      // Map pixel coordinates to the complex plane
      const x0 = xMin + (w / width) * (xMax - xMin);
      const y0 = yMin + (h / height) * (yMax - yMin);
      
      // Calculate if the point is in the Mandelbrot set
      const iteration = calculateMandelbrot(x0, y0, maxIterations);
      
      // Choose a character based on the number of iterations
      const char = chooseChar(iteration, maxIterations);
      line += char;
    }
    lines.push(line);
  }
  
  return lines.join('\n');
}

// Function to display usage instructions
function displayUsage() {
  console.log('\nMandelbrot Set ASCII Renderer');
  console.log('===========================');
  console.log('Usage: deno run mandelbrot.js [width] [height] [xMin] [xMax] [yMin] [yMax] [maxIterations]');
  console.log('Default values:');
  console.log('  width = 80, height = 40');
  console.log('  xMin = -2.0, xMax = 1.0');
  console.log('  yMin = -1.0, yMax = 1.0');
  console.log('  maxIterations = 100');
  console.log('\nTry zooming in by specifying a smaller region!');
}

// Main function to parse command line arguments and render the Mandelbrot set
function main(args) {
  // Default values
  const width = +args[0] || 80;
  const height = +args[1] || 40;
  const xMin = +args[2] || -2.0;
  const xMax = +args[3] || 1.0;
  const yMin = +args[4] || -1.0;
  const yMax = +args[5] || 1.0;
  const maxIterations = +args[6] || 100;
  
  // Display usage information
  displayUsage();
  
  // Render and display the Mandelbrot set
  console.log('\nRendering Mandelbrot set with the following parameters:');
  console.log(`Width: ${width}, Height: ${height}`);
  console.log(`X range: [${xMin}, ${xMax}]`);
  console.log(`Y range: [${yMin}, ${yMax}]`);
  console.log(`Max iterations: ${maxIterations}`);
  console.log('\nOutput:');
  
  const mandelbrotSet = renderMandelbrot(width, height, xMin, xMax, yMin, yMax, maxIterations);
  console.log(mandelbrotSet);
}

// Execute the program
main(Deno.args);