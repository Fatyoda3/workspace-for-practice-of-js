# Mandelbrot Set ASCII Renderer

This program renders a textual representation of the famous Mandelbrot set using ASCII characters.

## What is the Mandelbrot Set?

The Mandelbrot set is one of the most famous fractals in mathematics. It's a set of complex numbers for which a certain function doesn't escape to infinity when iterated. The visual representation shows intricate, infinitely detailed patterns that remain interesting at any level of magnification.

## Usage

```
deno run mandelbrot.js [width] [height] [xMin] [xMax] [yMin] [yMax] [maxIterations]
```

### Parameters

- `width`: Width of the output (default: 80)
- `height`: Height of the output (default: 40)
- `xMin`: Minimum x-coordinate (default: -2.0)
- `xMax`: Maximum x-coordinate (default: 1.0)
- `yMin`: Minimum y-coordinate (default: -1.0)
- `yMax`: Maximum y-coordinate (default: 1.0)
- `maxIterations`: Maximum iterations for each point (default: 100)

## Examples

### Default View

```
deno run mandelbrot.js
```

### Zoom into an interesting region

```
deno run mandelbrot.js 100 50 -0.7 -0.5 0.45 0.65 200
```

## Exploration Ideas

1. **Experiment with different coordinates** - Try zooming in on different parts of the Mandelbrot set by changing the x and y ranges. The Mandelbrot set is infinitely detailed!

2. **Change the maximum iterations** - Higher values produce more detailed results but take longer to compute.

3. **Modify the character set** - Try changing the characters used to render different "depths" in the `chooseChar()` function.

## Key Concepts

### Complex Numbers

The Mandelbrot set operates in the complex plane, where each point represents a complex number (a + bi). In our program, the x-coordinate represents the real part and the y-coordinate represents the imaginary part.

### Iterative Functions

The Mandelbrot set is defined by an iterative function: z\_{n+1} = z_n^2 + c, where c is the complex number we're testing. We start with z_0 = 0 and iterate. If the sequence remains bounded (doesn't escape to infinity), the point is in the Mandelbrot set.

### Fractals

Fractals are infinitely complex patterns that are self-similar across different scales. The Mandelbrot set is a fractal, exhibiting incredible detail no matter how much you zoom in.

## Real-World Applications

Fractals like the Mandelbrot set have applications in:

- Computer graphics and generating realistic-looking landscapes
- Antenna design for better reception across multiple wavelengths
- Analyzing stock market patterns and other complex systems
- Compression algorithms for images and data
- Modeling natural structures like coastlines, clouds, and plant growth patterns

Have fun exploring the infinite complexity of the Mandelbrot set!
