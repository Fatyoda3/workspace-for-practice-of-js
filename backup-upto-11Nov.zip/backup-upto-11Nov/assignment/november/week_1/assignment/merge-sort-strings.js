const merge = function () { }


const sort = function (array = []) {

  return mer
}