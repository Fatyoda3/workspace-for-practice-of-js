const main = function () {
  const string = 'ABCabc';
  for (let index = 0; index < string.length; index++) {
    console.log((string.charCodeAt(index)));
  }
}

main();
