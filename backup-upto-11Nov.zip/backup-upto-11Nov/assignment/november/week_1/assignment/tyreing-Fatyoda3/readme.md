# <span style="color:#4FC3F7;">Just some things</span>
------
## <span style="color:#81C784;">I must write the *contract*.</span>  
## <span style="color:#64B5F6;">I must write the *code*.</span>  
## <span style="color:#BA68C8;">I must write the *tests*.</span>  
## <span style="color:#FFD54F;">I must *push* the *code* regularly.</span>  
## <span style="color:#FF8A65;">I must update *variable*, *file names* accordingly.</span>
------ 