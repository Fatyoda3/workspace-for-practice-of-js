Parallel arrays are considered poor design because the data is **related in your mind, but not in the code**. The connection between countries[i] and capitals[i] is only based on remembering that the same index in each array must match. Nothing in the program itself enforces that rule. If someone adds, removes, or sorts one array but forgets to make the exact same change to the other, the data becomes incorrect — and the bug may be very hard to find. As your program grows, keeping multiple arrays perfectly synchronized becomes harder and riskier.

For example, with parallel arrays:

js
const countries = ['India', 'Japan'];
const capitals = ['New Delhi', 'Tokyo'];

// Someone inserts a new country but forgets to update the capitals array:
countries.push('France');

// Now countries[2] is 'France' but capitals[2] is undefined — the data is broken.



A better practice — even before learning objects — is to use **one array where each entry contains all the related data together**, such as an array of small sub-arrays:

js
const places = [
  ['India', 'New Delhi'],
  ['Japan', 'Tokyo']
];

// Everything for one place stays together in one element.



This way, the relationship is kept inside one array, so you can’t accidentally break it by changing different arrays independently.