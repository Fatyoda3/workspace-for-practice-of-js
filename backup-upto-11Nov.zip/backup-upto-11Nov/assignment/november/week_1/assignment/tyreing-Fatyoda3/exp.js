// const numbers = [1, 12, 14];

// const mappedValues = numbers.map((val, index, array) => {
//   console.log('now array is:', array);
//   return val + index;
// });
// console.log('values after map', mappedValues);

const stars = times => '*'.repeat(times);

const repeatMN = (m, n) => {
  const pattern = [];
  for (let i = 0; i < m; i++) {
    pattern.push(stars(n));
  }
  return pattern;
}
console.log(repeatMN(5, 2).join('\n'));