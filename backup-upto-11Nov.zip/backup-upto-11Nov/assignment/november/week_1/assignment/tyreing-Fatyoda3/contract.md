## Must do
### Write a function that calculates the square root of ***every value*** in an array. Return a new array that contains all the square roots.
```
Example: [1,4,9,16] => [1,2,3,4]
```
### Write a function that selects only the ***odd numbers*** in an array.
``` 
Example: [1,2,3,4] => [1,3] 
```

### Write a function that calculates half the value of every value in an array.
```
Example: [10,20,31] => [5,10,15.5]
```

### Write a function that selects only the strings with more than 5 characters.
```
Example: ["impossible", "possible", "no"] => ["impossible", "possible"]
```
### Write a function that converts every string in an array to uppercase.
```
Example: ["hello","goodbye"] => ["HELLO", "GOODBYE"]
```

### Write a function that finds the longest string in an array.
```
Example: ["this","amazing", "assignment", "rocks"] => "assignment"
```
### Write a function that combines all strings in an array into one.(Don't use join)
```
Example: ["ab","so","lu","te"] => "absolute"
```
### Write a function that counts how many odd numbers are in an array.
```
Example: [1,2,3,4,5] => 3
```
### Write a function that checks if there is at least one odd number in an array.
```
Example:
[1,2,3,4] => true
[2,4] => false
```

### Write a function that checks if there is at least one odd number in an array.
```
Example:
[1,2,3,4] => true
[2,4] => false

```
### Write a function that checks if all numbers in an array are positive.
```
Example: [1,2,3] => true
[-1,-2] => false
```
### Write a function that checks if all strings in an array have more than 3 characters.

```
Example: ["this", "that"] => true
["or","not"] => false
```
-----
