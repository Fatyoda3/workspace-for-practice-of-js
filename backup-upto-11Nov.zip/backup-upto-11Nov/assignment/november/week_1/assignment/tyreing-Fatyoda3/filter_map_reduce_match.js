const map = (values, convert) => {
  const mapped = [];

  for (let index = 0; index < values.length; index++) {
    mapped.push(convert(values[index]));
  }

  return mapped;
}
const filter = (values, predicate) => {
  const filtered = [];

  for (let index = 0; index < values.length; index++) {
    const element = values[index];
    if (predicate(element)) {
      filtered.push(element);
    }
  }

  return filtered;
}
const reduce = (values, initial, reducer) => {
  let reduced = initial;

  for (let index = 0; index < values.length; index++) {
    reduced = reducer(reduced, values[index]);
  }

  return reduced;
}
const some = (value, predicate, threshold) => {
  for (let index = 0; index < value.length; index++) {
    if (predicate(value[index], threshold)) return true;
  }

  return false;
}
const every = (value, predicate) => {
  for (let index = 0; index < value.length; index++) {
    if (!predicate(value[index])) {
      return false;
    }
  }
  return true;
}

const color = (text, code) => `\x1B[38;5;${code}m${text}\x1B[0m`;
const bold = text => `\x1B[1m${text}\x1B[0m`;
const fmtMsg = (input, output, expected, purpose) => {
  const PrintError = !areEqual(output, expected);
  const symbol = PrintError ? "❌ " : "✅ ";
  const message = [symbol, bold(purpose.toUpperCase())];

  if (PrintError) {
    const inpFrag = `INP -> ${color(input, 222)}`;
    const expFrag = `EXP -> ${color(expected, 45)}`;
    const outFrag = `OUT -> ${color(output, 196)}`;
    message.push(`\n${inpFrag} \n${expFrag} \n${outFrag}\n`);
  }

  return color(message.join(""), 155);
}
const tester = (fnToTest, input, expected, intent) => {
  const result = fnToTest(...input);
  const message = fmtMsg(input, result, expected, intent);
  console.log(message);
}
const areEqual = (comparand, comparator) => {
  if (areSame(comparand, comparator)) {
    return true;
  }
  if (!(Array.isArray(comparand)) || !(Array.isArray(comparator))) {
    return false;
  }
  if (comparand.length !== comparator.length) {
    return false
  }
  for (let index = 0; index < comparand.length; index++) {
    if (comparand[index] !== comparator[index]) {
      return false;
    }
  }
  return true;
}
const areSame = (comparand, comparator) => comparand === comparator;

const testSqrRoot = (fn, mapper) => {
  console.log('Square root function test');
  tester(fn, [[16, 4, 9, 25], mapper], [4, 2, 3, 5], 'whole numbers');
  tester(fn, [[], mapper], [], 'empty test');

  console.log('------END-------');
}
const testFilterOdd = (fn, mapper) => {
  console.log('test filter odd')
  tester(fn, [[16, 4, 9, 25], mapper], [9, 25], 'basic test');
  tester(fn, [[1600, 64, 82, 62], mapper], [], 'No Odds');
  tester(fn, [[], mapper], [], 'empty test');

  console.log('------END-------');
}
const testHalfThese = (fn, mapper) => {
  tester(fn, [[16, 4, 9, 25], mapper], [8, 2, 4.5, 12.5], 'basic test');
  tester(fn, [[0, 64], mapper], [0, 32], 'Zero and whole half');
  console.log('------END-------');
}
const testUpperCase = (fn, mapper) => {
  tester(fn, [['hello'], mapper], ["HELLO"], 'basic test unary element array');
  tester(fn, [[''], mapper], [''], 'empty output');
}
const testLongestStr = (fn, reducer) => {
  tester(fn, [['hello'], '', reducer], "hello", 'basic test unary element array');
  tester(fn, [[''], '', reducer], '', 'empty output');
  tester(fn, [["this", "amazing", "assignment", "rocks"], '', reducer], 'assignment', 'multiple el');
  console.log('------END-------');
}
const testJoinStrings = (fn, reducer) => {
  tester(fn, [['hello'], '', reducer], "hello", 'basic test unary element array');
  tester(fn, [[''], '', reducer], '', 'empty output');
  tester(fn, [["ab", "so", "lu", "te"], '', reducer], "absolute", 'multiple elements');
  console.log('------END-------');
}

const testMultiplyThese = (fn, reducer) => {
  tester(fn, [[2, 4, 6], 1, reducer], 48, 'simple test');
  tester(fn, [[1], 1, reducer], 1, 'empty output');
  tester(fn, [[5, 5, 5], 1, reducer], 125, 'multiple elements');
  console.log('------END-------');
}

const testCountOdds = (fn, reducer) => {
  tester(fn, [[2, 4, 6], 0, reducer], 0, 'simple test');
  tester(fn, [[1], 0, reducer], 1, 'empty output');
  tester(fn, [[5, 5, 5], 0, reducer], 3, 'multiple elements');
  console.log('------END-------');
}

const testLenGreater = (fn, predicate) => {
  tester(fn, [['HELLO1'], predicate], ["HELLO1"], 'basic test unary element array');
  tester(fn, [['abc'], predicate], [], 'empty output');
  const LEN_10 = 'a'.repeat(10);
  tester(fn, [['abc', LEN_10], predicate], [LEN_10], 'empty output');
  console.log('------END-------');
}

const testAtLeastOneOdd = (fn, predicate) => {
  tester(fn, [[2, 4, 6], predicate], false, 'simple test');
  tester(fn, [[1], predicate], true, 'empty output');
  tester(fn, [[5, 5, 5], predicate], true, 'multiple elements');
  tester(fn, [[1, 2, 3, 4], predicate], true, 'multiple elements');
  console.log('------END-------');
}

const testAtLeastOneGreaterThan100 = (fn, predicate, threshold) => {
  tester(fn, [[2, 4, 6], predicate, threshold], false, 'simple test');
  tester(fn, [[1], predicate, threshold], false, 'empty output');
  tester(fn, [[5, 5, 5], predicate, threshold], false, 'multiple elements');
  tester(fn, [[1, 2000, 3, 4], predicate, threshold], true, 'multiple elements');
  console.log('------END-------');
}

const testAllPositive = (fn, predicate, threshold) => {
  tester(fn, [[2, 4, 6], predicate, threshold], true, 'simple test');
  tester(fn, [[1], predicate, threshold], true, 'empty output');
  tester(fn, [[5, -5, 5], predicate, threshold], false, 'multiple elements');
}

const testLenGrtThan5 = (fn, predicate) => {
  tester(fn, [['ja', 'cake'], predicate], false, 'simple test');
  tester(fn, [["this", "amazing", "assignment", "rocks"], predicate], true, 'multiple elements');
}

const isGreaterThan = (value, threshold = 0) => value >= threshold;
const isOdd = (value) => value & 1 === 1;
const countOdd = (count, value) => isOdd(value) ? count + 1 : count;

const testAllMapCases = () => {
  testSqrRoot(map, Math.sqrt);
  testHalfThese(map, value => value / 2);
  testUpperCase(map, text => text.toUpperCase());
}
const testFilterCases = () => {
  testLenGreater(filter, text => 5 < text.length);
  testFilterOdd(filter, isOdd);
}
const testReduceCases = () => {
  testLongestStr(reduce, (current, longest) => current.length > longest.length ? current : longest);
  testJoinStrings(reduce, (value1, value2) => value1 + value2);
  testMultiplyThese(reduce, (value1, value2) => value1 * value2);
}
const testMatchCases = () => {
  testAtLeastOneOdd(some, isOdd);
  testAtLeastOneGreaterThan100(some, isGreaterThan, 100);
  testAllPositive(every, isGreaterThan, 0);
  testLenGrtThan5(every, function (text) { return 3 < text.length; });
}

const main = function () {
  testAllMapCases();
  console.log('different fn call ');
  testFilterCases();
  console.log('different fn call ');
  testReduceCases();
  console.log('different fn call kind(filter and reduce ) ');
  testCountOdds(reduce, countOdd);
  console.log('different fn call kind(some match)');
  testMatchCases();
}
main(); 