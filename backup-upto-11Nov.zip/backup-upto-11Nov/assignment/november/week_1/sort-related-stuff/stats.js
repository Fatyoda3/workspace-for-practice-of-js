
function sort(data = []) {
  const sorted = data.slice();

  for (let i = 0; i < (data.length - 1); i++) {

    for (let j = i + 1; j < data.length; j++) {

      if (sorted[i] > sorted[j]) {
        const temp = sorted[i];
        sorted[i] = sorted[j];
        sorted[j] = temp;
      }
    }
  }

  return sorted;
}
function meanOf(data) {
  const n = data.length || 1;

  let sum = 0;
  for (let i = 0; i < n; i++) {
    sum += data[i];
  }

  const mean = sum / n;
  return mean;
}
function medianOf(data) {
  const sorted = sort(data);
  const midPoint = Math.floor(data.length / 2);
  const medianValue = sorted[midPoint];
  return medianValue;

}
function medianDeviation(sorted, meanOfData) {
  const variance = [];
  for (let i = 0; i < sorted.length; i++) {
    variance.push(sorted[i] - meanOfData);
  }
  return variance;
}

function varianceOf(differences) {
  let sumOfSquares = 0;

  for (let index = 0; index < differences.length; index++) {
    sumOfSquares += Math.pow(differences[index], 2);
  }

  return Math.sqrt(sumOfSquares / differences.length);
}
function consistencyOf(data,) {
  const meanOfData = meanOf(data);
  const differences = medianDeviation(data, meanOfData);

  const variance = varianceOf(differences);
  const consistency = meanOfData - variance;

  return consistency.toFixed(3);
}

function main() {
  const N = '\n';

  const IPL2016 = [75, 79, 33, 80, 100, 14, 52, 108, 20, 7, 109, 75, 113, 54, 0, 54];
  const IPL2017 = [58, 5, 6, 20, 55, 10, 0, 64, 28, 62];
  const IPL2018 = [31, 21, 57, 92, 18, 68, 32, 8, 39, 70, 48, 12, 4];
  const ODI2018 = [112, 46, 160, 75, 36, 129, 45, 39, 140, 157, 38, 60, 107, 129, 63];
  const IPL2024 = [75, 79, 33, 80, 100, 14, 52, 108, 20, 7, 109, 75, 113, 54, 0, 54];

  console.log("IPL 2016: " + consistencyOf(IPL2016) + N);
  console.log("IPL 2017: " + consistencyOf(IPL2017) + N);
  console.log("IPL 2018: " + consistencyOf(IPL2018) + N);
  console.log("IPL 2018: " + consistencyOf(IPL2024) + N);
  console.log("ODI 2018: " + consistencyOf(ODI2018) + N);
}

main();