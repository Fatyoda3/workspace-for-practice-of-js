//internal command -- which cd pwd clear exit -- done
//external command -- fish animated 
const EXIT = function () {
  console.log('BYE !');
}
const isCommandInternal = function (command) {
  const internalCommands = ['cd', 'which', 'pwd', 'clear'];
  return (internalCommands.includes(command));
}
const cd = function (commandArgs) {
  console.log('in directory', commandArgs || '.');
}
const pwd = function () {
  console.log('present working directory : c:\\');
}
const clearSCR = function () {
  console.clear();
}
const which = function (commandArgs) {
  switch (commandArgs) {
    case 'which':
      console.log(which.toString());
      break;
    case 'cd':
      console.log(cd.toString());
      break;
    case 'pwd':
      console.log(pwd.toString());
      break;
    case 'clear':
      console.log(clearSCR.toString());
      break;
    default:
      console.log('command not found!');
      break;
  }
}
const executeCommand = function (commandTokens) {
  const arg = commandTokens[1];
  switch (commandTokens[0]) {
    case 'which':
      console.log(which(arg));
      break;
    case 'cd':
      console.log(cd(arg));
      break;
    case 'pwd':
      console.log(pwd());
      break;
    case 'clear':
      clearSCR();
      break;
    case 'exit':
      return "EXIT";
    default:
      console.log('command not found!');
      break;
  }
}
const shell = function () {

  while (true) {
    const commandTokenized = prompt('shell>').split(' ');
    if (isCommandInternal(commandTokenized[0])) {
      console.log('internal command executed');
    }
    if (executeCommand(commandTokenized)) {
      return EXIT();
    }
  }
}

shell();